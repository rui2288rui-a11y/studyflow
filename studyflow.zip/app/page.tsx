"use client";

import { useEffect, useMemo, useState } from "react";
import {
  CalendarClock, Flame, Target, ChevronRight, Clock, ListChecks, Trash2, Check,
} from "lucide-react";
import { useAppStore } from "@/lib/store";
import { EXAM_PRESETS } from "@/lib/constants";
import { diffParts, daysUntil, formatJapaneseDate, formatMinutes } from "@/lib/datetime";
import { minutesOn, streakDays, totalMinutes } from "@/lib/stats";
import { buildPlan } from "@/lib/planner";
import CountdownFlip from "@/components/CountdownFlip";
import GoalForm from "@/components/GoalForm";

export default function HomePage() {
  const { goal, subjects, logs, tasks, settings, toggleTask } = useAppStore();
  const [, forceTick] = useState(0);

  // 1秒ごとに再描画してリアルタイムカウントダウン
  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  }, []);

  const todayMinutes = minutesOn(logs, todayStr);
  const streak = streakDays(logs);
  const total = totalMinutes(logs);
  const todayTasks = tasks.filter((t) => t.date === todayStr);
  const doneCount = todayTasks.filter((t) => t.done).length;

  const plan = useMemo(
    () =>
      goal
        ? buildPlan({ goal, subjects, logs, tasks, settings })
        : null,
    [goal, subjects, logs, tasks, settings]
  );

  if (!goal) {
    return (
      <div className="fade-up mx-auto max-w-lg px-4 py-8">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-fuchsia-600 text-white shadow-lg shadow-indigo-600/30">
            <Target size={26} />
          </div>
          <h1 className="text-2xl font-extrabold">目標を設定しよう</h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            試験日を設定するとカウントダウンと自動計画がスタートします。
          </p>
        </div>
        <GoalForm />
      </div>
    );
  }

  const targetMs = new Date(goal.examDate).getTime();
  const parts = diffParts(targetMs, Date.now());
  const remaining = daysUntil(targetMs, Date.now());
  const preset = EXAM_PRESETS.find((p) => p.id === goal.presetId);

  // 本番当日までの進捗（目標作成日からの経過率）
  const createdMs = new Date(goal.createdAt).getTime();
  const progress = Math.min(
    100,
    Math.max(0, ((Date.now() - createdMs) / (targetMs - createdMs)) * 100)
  );

  return (
    <div className="fade-up mx-auto max-w-2xl space-y-5 px-4 py-6">
      {/* ---------- ヒーロー：カウントダウン ---------- */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-6 text-white shadow-xl shadow-indigo-600/20">
        <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-14 -left-8 h-44 w-44 rounded-full bg-fuchsia-400/20 blur-2xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-xs font-semibold text-white/80">
            <CalendarClock size={14} />
            {formatJapaneseDate(goal.examDate)}
          </div>
          <h1 className="mt-1.5 truncate text-xl font-extrabold sm:text-2xl">{goal.title}</h1>
          {preset?.note && (
            <p className="mt-1 text-[11px] leading-relaxed text-white/70">{preset.note}</p>
          )}
          <p className="mt-3 text-sm font-semibold text-white/90">
            {parts.isPast ? "試験当日です。力を出し切ろう！" : `本番まで 残り ${remaining} 日`}
          </p>

          {!parts.isPast && (
            <CountdownFlip
              days={parts.days}
              hours={parts.hours}
              minutes={parts.minutes}
              seconds={parts.seconds}
            />
          )}

          <div className="mt-4">
            <div className="mb-1 flex justify-between text-[11px] font-semibold text-white/80">
              <span>目標設定から本番まで</span>
              <span className="tabular">{progress.toFixed(0)}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-white/25">
              <div
                className="h-full rounded-full bg-white/90 transition-all duration-1000"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* ---------- ステータスカード ---------- */}
      <section className="grid grid-cols-3 gap-3">
        <div className="card flex flex-col items-center gap-1 p-4">
          <Flame size={18} className="text-orange-500" />
          <span className="text-2xl font-extrabold tabular">{streak}</span>
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">日連続学習</span>
        </div>
        <div className="card flex flex-col items-center gap-1 p-4">
          <Clock size={18} className="text-indigo-500" />
          <span className="text-2xl font-extrabold tabular">{todayMinutes}</span>
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">今日の学習(分)</span>
        </div>
        <div className="card flex flex-col items-center gap-1 p-4">
          <Target size={18} className="text-fuchsia-500" />
          <span className="text-2xl font-extrabold tabular">{Math.round(total / 60)}</span>
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">累計(時間)</span>
        </div>
      </section>

      {/* ---------- 今日やるべきこと ---------- */}
      <section className="card p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-extrabold">
            <ListChecks size={16} className="text-indigo-500" />
            今日やるべきこと（AIプラン）
          </h2>
          <span className="text-xs font-semibold text-slate-400 tabular">
            {doneCount}/{todayTasks.length} 完了
          </span>
        </div>
        {todayTasks.length === 0 ? (
          <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
            今日のタスクはまだありません。
            <a href="/plan" className="ml-1 font-semibold text-indigo-600 underline dark:text-indigo-400">
              計画ページで自動生成
            </a>
          </div>
        ) : (
          <ul className="space-y-2">
            {todayTasks.map((t) => (
              <li
                key={t.id}
                className={`flex items-center gap-3 rounded-xl border p-3 transition-colors ${
                  t.done
                    ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/40"
                    : "border-slate-200 dark:border-slate-700"
                }`}
              >
                <button
                  onClick={() => toggleTask(t.id)}
                  aria-label={t.done ? "タスクを未完了にする" : "タスクを完了にする"}
                  className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                    t.done
                      ? "border-emerald-500 bg-emerald-500 text-white"
                      : "border-slate-300 dark:border-slate-600"
                  }`}
                >
                  {t.done && <Check size={13} strokeWidth={3} />}
                </button>
                <div className="min-w-0 flex-1">
                  <p className={`truncate text-sm font-semibold ${t.done ? "text-slate-400 line-through" : ""}`}>
                    {t.title}
                  </p>
                  <p className="text-[11px] text-slate-400">{t.subjectName}</p>
                </div>
                <span className="shrink-0 rounded-full bg-indigo-50 px-2 py-0.5 text-[11px] font-bold text-indigo-600 tabular dark:bg-indigo-950/60 dark:text-indigo-300">
                  {formatMinutes(t.minutes)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ---------- AIアドバイス ---------- */}
      {plan && plan.advice.length > 0 && (
        <section className="card p-5">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
            <Target size={16} className="text-fuchsia-500" />
            AIアドバイス
          </h2>
          <ul className="space-y-2">
            {plan.advice.map((a, i) => (
              <li
                key={i}
                className="flex items-start gap-2 rounded-xl bg-gradient-to-r from-indigo-50 to-fuchsia-50 p-3 text-sm dark:from-indigo-950/40 dark:to-fuchsia-950/40"
              >
                <ChevronRight size={14} className="mt-0.5 shrink-0 text-fuchsia-500" />
                <span className="text-slate-700 dark:text-slate-200">{a}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* ---------- 目標の変更 ---------- */}
      <details className="card p-5">
        <summary className="cursor-pointer text-sm font-extrabold">目標を変更する</summary>
        <div className="mt-4">
          <GoalForm initial={goal} />
        </div>
      </details>
    </div>
  );
}
