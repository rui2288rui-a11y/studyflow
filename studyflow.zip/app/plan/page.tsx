"use client";

import { useMemo, useState } from "react";
import { CalendarCheck, Sparkles, Plus, Trash2, Check, Info } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { buildPlan } from "@/lib/planner";
import { formatJapaneseDate, formatMinutes, todayKey } from "@/lib/datetime";
import type { PlannedTask } from "@/types";

export default function PlanPage() {
  const { goal, subjects, logs, tasks, settings, addAutoTasks, toggleTask, removeTask, addManualTask } =
    useAppStore();
  const [generated, setGenerated] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [newMinutes, setNewMinutes] = useState(30);

  const plan = useMemo(
    () => (goal ? buildPlan({ goal, subjects, logs, tasks, settings }) : null),
    [goal, subjects, logs, tasks, settings]
  );

  const today = todayKey();
  const todayTasks = tasks.filter((t) => t.date === today);
  const upcoming = tasks
    .filter((t) => t.date > today)
    .sort((a, b) => a.date.localeCompare(b.date));

  if (!goal) {
    return (
      <div className="fade-up mx-auto max-w-lg px-4 py-10 text-center">
        <CalendarCheck size={40} className="mx-auto text-indigo-500" />
        <h1 className="mt-3 text-xl font-extrabold">自動計画</h1>
        <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
          まず<a href="/" className="mx-1 font-semibold text-indigo-600 underline dark:text-indigo-400">ホーム</a>で試験日を設定すると、
          残り日数と点数ギャップから「今日やるべきこと」を自動で逆算します。
        </p>
      </div>
    );
  }

  const generate = () => {
    if (!plan) return;
    // 手動タスク・完了済み・過去日のタスクを保持し、未完了の自動タスクを再生成して入れ替え
    const keep = tasks.filter((t) => t.source === "manual" || t.done || t.date < today);
    const auto = plan.dailyTargets
      .filter((t) => !tasks.some((x) => x.source === "manual" && x.date === t.date && x.subjectName === t.subjectName && x.title === t.title))
      .map((t) => ({ ...t, done: false, source: "auto" as const }));
    useAppStore.setState({ tasks: [...auto, ...keep] });
    setGenerated(true);
  };

  const addTask = () => {
    if (!newTitle.trim()) return;
    addManualTask(newSubject || subjects[0]?.name || "その他", newTitle.trim(), newMinutes, today);
    setNewTitle("");
  };

  const TaskRow = ({ t }: { t: PlannedTask }) => (
    <li
      className={`flex items-center gap-3 rounded-xl border p-3 ${
        t.done
          ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/40"
          : t.source === "auto"
            ? "border-indigo-100 bg-indigo-50/60 dark:border-indigo-900/60 dark:bg-indigo-950/30"
            : "border-slate-200 dark:border-slate-700"
      }`}
    >
      <button
        onClick={() => toggleTask(t.id)}
        aria-label="完了切替"
        className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${
          t.done ? "border-emerald-500 bg-emerald-500 text-white" : "border-slate-300 dark:border-slate-600"
        }`}
      >
        {t.done && <Check size={13} strokeWidth={3} />}
      </button>
      <div className="min-w-0 flex-1">
        <p className={`truncate text-sm font-semibold ${t.done ? "text-slate-400 line-through" : ""}`}>
          {t.title}
        </p>
        <p className="text-[11px] text-slate-400">
          {t.date !== today ? `${t.date} ・ ` : ""}
          {t.subjectName}
          {t.source === "auto" ? " ・ AI生成" : ""}
        </p>
      </div>
      <span className="shrink-0 text-xs font-bold tabular text-indigo-600 dark:text-indigo-300">
        {formatMinutes(t.minutes)}
      </span>
      <button
        onClick={() => removeTask(t.id)}
        aria-label="削除"
        className="shrink-0 rounded-lg p-1.5 text-slate-300 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-950/50"
      >
        <Trash2 size={15} />
      </button>
    </li>
  );

  return (
    <div className="fade-up mx-auto max-w-2xl space-y-5 px-4 py-6">
      <header>
        <h1 className="text-xl font-extrabold">自動計画</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          {formatJapaneseDate(goal.examDate)} に向けて、残り {plan?.remainingDays ?? 0} 日の学習を逆算します。
        </p>
      </header>

      {/* ---------- 計画サマリ ---------- */}
      {plan && (
        <section className="card space-y-3 p-5">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-xl font-black tabular">{plan.remainingDays}</p>
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">残り日数</p>
            </div>
            <div>
              <p className="text-xl font-black tabular">{plan.requiredMinutes >= 60 ? `${(plan.requiredMinutes / 60).toFixed(1)}時間` : `${plan.requiredMinutes}分`}</p>
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">必要学習時間</p>
            </div>
            <div>
              <p className={`text-xl font-black tabular ${plan.loadRatio > 100 ? "text-red-500" : "text-emerald-500"}`}>
                {Number.isFinite(plan.loadRatio) ? `${Math.round(plan.loadRatio)}%` : "—"}
              </p>
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">計画負荷率</p>
            </div>
          </div>

          {plan.plans.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">科目別の時間配分（残り日数全体）</p>
              {plan.plans.map((p) => (
                <div key={p.subjectId} className="flex items-center gap-2">
                  <span className="w-20 shrink-0 truncate text-xs font-semibold">{p.subjectName}</span>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${plan.availableMinutes ? (p.allocatedMinutes / plan.availableMinutes) * 100 : 0}%`,
                        backgroundColor: p.color,
                      }}
                    />
                  </div>
                  <span className="w-16 shrink-0 text-right text-[11px] font-bold tabular text-slate-500 dark:text-slate-400">
                    {formatMinutes(p.allocatedMinutes)}
                  </span>
                </div>
              ))}
            </div>
          )}

          <ul className="space-y-1.5">
            {plan.advice.map((a, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
                <Info size={12} className="mt-0.5 shrink-0 text-indigo-400" />
                {a}
              </li>
            ))}
          </ul>

          <button onClick={generate} className="btn-primary w-full">
            <Sparkles size={16} />
            {generated ? "再生成する" : "今日〜3日分のタスクを自動生成"}
          </button>
        </section>
      )}

      {/* ---------- 今日のタスク ---------- */}
      <section className="card p-5">
        <h2 className="mb-3 text-sm font-extrabold">今日のタスク（{todayTasks.length}件）</h2>
        {todayTasks.length === 0 ? (
          <p className="text-sm text-slate-400">自動生成または下のフォームから追加してください。</p>
        ) : (
          <ul className="space-y-2">
            {todayTasks.map((t) => (
              <TaskRow key={t.id} t={t} />
            ))}
          </ul>
        )}

        {/* 手動追加フォーム */}
        <div className="mt-4 flex gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
          <select
            value={newSubject}
            onChange={(e) => setNewSubject(e.target.value)}
            className="shrink-0 rounded-xl border border-slate-200 bg-transparent px-2 py-2 text-xs dark:border-slate-700"
          >
            <option value="">科目…</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.name}>{s.name}</option>
            ))}
          </select>
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="タスクを追加（例: 過去問 演習）"
            className="min-w-0 flex-1 rounded-xl border border-slate-200 bg-transparent px-3 py-2 text-sm outline-none focus:border-indigo-500 dark:border-slate-700"
          />
          <input
            type="number"
            min={5}
            step={5}
            value={newMinutes}
            onChange={(e) => setNewMinutes(Math.max(5, Number(e.target.value) || 5))}
            className="w-16 shrink-0 rounded-xl border border-slate-200 bg-transparent px-2 py-2 text-center text-xs tabular dark:border-slate-700"
          />
          <button onClick={addTask} className="btn-primary shrink-0 px-3" aria-label="タスク追加">
            <Plus size={16} />
          </button>
        </div>
      </section>

      {/* ---------- 明日以降 ---------- */}
      {upcoming.length > 0 && (
        <section className="card p-5">
          <h2 className="mb-3 text-sm font-extrabold">明日以降の予定</h2>
          <ul className="space-y-2">
            {upcoming.map((t) => (
              <TaskRow key={t.id} t={t} />
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
