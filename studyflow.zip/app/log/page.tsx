"use client";

import { useMemo, useState } from "react";
import { Trash2, Timer, BarChart3 } from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts";
import { useAppStore } from "@/lib/store";
import { lastNDays, minutesBySubject, totalMinutes } from "@/lib/stats";
import { formatMinutes } from "@/lib/datetime";
import Stopwatch from "@/components/Stopwatch";

const tooltipStyle = {
  backgroundColor: "rgba(15,23,42,0.92)",
  border: "none",
  borderRadius: "12px",
  color: "#f1f5f9",
  fontSize: "12px",
};

export default function LogPage() {
  const { logs, subjects, removeLog } = useAppStore();
  const [range, setRange] = useState<7 | 14 | 30>(14);

  const chartData = useMemo(() => lastNDays(logs, range), [logs, range]);
  const pieData = useMemo(() => minutesBySubject(logs), [logs]);
  const subjectNames = useMemo(() => subjects.map((s) => s.name), [subjects]);
  const total = totalMinutes(logs);

  return (
    <div className="fade-up mx-auto max-w-2xl space-y-5 px-4 py-6">
      <header>
        <h1 className="text-xl font-extrabold">学習記録</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          ストップウォッチで計測して、今日の学習を記録しましょう。
        </p>
      </header>

      <Stopwatch />

      {/* ---------- グラフ ---------- */}
      <section className="card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-extrabold">
            <BarChart3 size={16} className="text-indigo-500" />
            学習時間の推移
          </h2>
          <div className="flex gap-1 rounded-full bg-slate-100 p-0.5 dark:bg-slate-800">
            {([7, 14, 30] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`rounded-full px-2.5 py-1 text-[11px] font-bold transition-colors ${
                  range === r ? "bg-white text-indigo-600 shadow dark:bg-slate-700 dark:text-indigo-300" : "text-slate-400"
                }`}
              >
                {r}日
              </button>
            ))}
          </div>
        </div>
        {total === 0 ? (
          <p className="py-8 text-center text-sm text-slate-400">まだ記録がありません。</p>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 4, right: 0, left: -24, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#94a3b8" }} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatMinutes(v)} />
                {subjectNames.map((name, i) => (
                  <Bar
                    key={name}
                    dataKey={name}
                    stackId="a"
                    fill={subjects[i]?.color ?? "#6366f1"}
                    radius={i === subjectNames.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                  />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      {/* ---------- 科目別円グラフ ---------- */}
      {pieData.length > 0 && (
        <section className="card p-5">
          <h2 className="mb-2 text-sm font-extrabold">科目別の累計時間</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="minutes"
                  nameKey="name"
                  innerRadius="50%"
                  outerRadius="75%"
                  paddingAngle={3}
                >
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={subjects.find((s) => s.name === entry.name)?.color ?? "#6366f1"} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => formatMinutes(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      {/* ---------- 記録一覧 ---------- */}
      <section className="card p-5">
        <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
          <Timer size={16} className="text-indigo-500" />
          記録一覧（{logs.length}件／合計 {formatMinutes(total)}）
        </h2>
        {logs.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">
            ストップウォッチまたは右下のボタンから記録できます。
          </p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {logs.slice(0, 50).map((l) => (
              <li key={l.id} className="flex items-center gap-3 py-3">
                <span
                  className="h-2.5 w-2.5 shrink-0 rounded-full"
                  style={{ backgroundColor: subjects.find((s) => s.id === l.subjectId)?.color ?? "#94a3b8" }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{l.subjectName}</p>
                  <p className="text-[11px] text-slate-400">
                    {l.date}
                    {l.memo ? ` ・ ${l.memo}` : ""}
                  </p>
                </div>
                <span className="shrink-0 text-sm font-bold tabular text-indigo-600 dark:text-indigo-300">
                  {formatMinutes(l.minutes)}
                </span>
                <button
                  onClick={() => removeLog(l.id)}
                  aria-label="記録を削除"
                  className="shrink-0 rounded-lg p-1.5 text-slate-300 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-950/50"
                >
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
