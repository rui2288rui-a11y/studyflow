"use client";

import { useMemo } from "react";
import { TrendingUp, AlertTriangle, Trophy, CalendarClock } from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LabelList, Cell,
} from "recharts";
import { useAppStore } from "@/lib/store";
import { minutesBySubjectId, totalMinutes } from "@/lib/stats";
import { formatMinutes } from "@/lib/datetime";
import type { Subject } from "@/types";

const tooltipStyle = {
  backgroundColor: "rgba(15,23,42,0.92)",
  border: "none",
  borderRadius: "12px",
  color: "#f1f5f9",
  fontSize: "12px",
};

function GapCard({ subject, minutes }: { subject: Subject; minutes: number }) {
  const gap = subject.targetScore - subject.currentScore;
  const rate = subject.targetScore === 0 ? 0 : (subject.currentScore / subject.targetScore) * 100;
  const achieved = gap <= 0;
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full" style={{ backgroundColor: subject.color }} />
          <h3 className="text-sm font-extrabold">{subject.name}</h3>
        </div>
        {achieved ? (
          <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-300">
            <Trophy size={12} /> 目標達成
          </span>
        ) : (
          <span className="flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-[11px] font-bold text-red-500 dark:bg-red-950/60 dark:text-red-300">
            <AlertTriangle size={12} /> あと{gap}点
          </span>
        )}
      </div>

      <div className="mt-3 flex items-end justify-between tabular">
        <span className="text-2xl font-black">{subject.currentScore}</span>
        <span className="pb-0.5 text-xs text-slate-400">/ 目標 {subject.targetScore}点</span>
      </div>
      <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${Math.min(100, rate)}%`, backgroundColor: subject.color }}
        />
      </div>

      {subject.weakUnits.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {subject.weakUnits.map((u) => (
            <span
              key={u}
              className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-500 dark:bg-slate-800 dark:text-slate-300"
            >
              弱点: {u}
            </span>
          ))}
        </div>
      )}
      <p className="mt-2 text-[11px] text-slate-400">累計学習 {formatMinutes(minutes)}</p>
    </div>
  );
}

export default function AnalysisPage() {
  const { subjects, logs } = useAppStore();

  const gapData = useMemo(
    () =>
      subjects.map((s) => ({
        name: s.name,
        ギャップ: Math.max(0, s.targetScore - s.currentScore),
        color: s.color,
      })),
    [subjects]
  );

  const minutesList = useMemo(() => minutesBySubjectId(logs, subjects), [logs, subjects]);
  const total = totalMinutes(logs);
  const totalGap = subjects.reduce((a, s) => a + Math.max(0, s.targetScore - s.currentScore), 0);
  const weakList = subjects.flatMap((s) =>
    s.weakUnits.map((u) => ({ subject: s.name, color: s.color, unit: u }))
  );

  return (
    <div className="fade-up mx-auto max-w-2xl space-y-5 px-4 py-6">
      <header>
        <h1 className="text-xl font-extrabold">点数・課題分析</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          目標点とのギャップと弱点を可視化します。
        </p>
      </header>

      {subjects.length === 0 ? (
        <div className="card p-8 text-center text-sm text-slate-500 dark:text-slate-400">
          まず<a href="/settings" className="mx-1 font-semibold text-indigo-600 underline dark:text-indigo-400">設定</a>で科目・目標点・実力を入力してください。
        </div>
      ) : (
        <>
          <section className="grid grid-cols-2 gap-3">
            <div className="card flex items-center gap-3 p-4">
              <TrendingUp size={22} className="text-fuchsia-500" />
              <div>
                <p className="text-xl font-black tabular">{totalGap}</p>
                <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">合計ギャップ(点)</p>
              </div>
            </div>
            <div className="card flex items-center gap-3 p-4">
              <CalendarClock size={22} className="text-indigo-500" />
              <div>
                <p className="text-xl font-black tabular">{formatMinutes(total)}</p>
                <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">総学習時間</p>
              </div>
            </div>
          </section>

          {gapData.length > 0 && (
            <section className="card p-5">
              <h2 className="mb-4 text-sm font-extrabold">科目別 不足点数</h2>
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gapData} margin={{ top: 20, right: 8, left: -24, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                    <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} />
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => `${v}点`} />
                    <Bar dataKey="ギャップ" radius={[6, 6, 0, 0]}>
                      <LabelList dataKey="ギャップ" position="top" fontSize={11} fill="#94a3b8" formatter={(v: number) => (v > 0 ? `${v}点` : "")} />
                      {gapData.map((d, i) => (
                        <Cell key={i} fill={d.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </section>
          )}

          <section className="space-y-3">
            <h2 className="text-sm font-extrabold">科目ごとの達成状況</h2>
            {minutesList.map(({ subject, minutes }) => (
              <GapCard key={subject.id} subject={subject} minutes={minutes} />
            ))}
          </section>

          {weakList.length > 0 && (
            <section className="card p-5">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
                <AlertTriangle size={16} className="text-amber-500" />
                重点克服リスト（弱点）
              </h2>
              <ul className="space-y-2">
                {weakList.map((w, i) => (
                  <li
                    key={i}
                    className="flex items-center gap-3 rounded-xl bg-amber-50 p-3 text-sm dark:bg-amber-950/40"
                  >
                    <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: w.color }} />
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{w.subject}</span>
                    <span className="text-slate-400">→</span>
                    <span className="text-slate-600 dark:text-slate-300">{w.unit}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  );
}
